package com.cg.opna.cart.controller;
 
import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.cart.exception.NoProperDataException;
import com.cg.opna.cart.exception.PlantNotFoundException;
import com.cg.opna.cart.model.Plant;
import com.cg.opna.cart.service.SequenceGeneratorService;
import com.cg.opna.cart.util.FeignClientUtilPlant;

 
  
  @RestController 
  @RequestMapping("/plant") //same url has this particular project
  @CrossOrigin(value = "http://localhost:3000")
  public class FeignControllerPlant {
  
  @Autowired 
  private FeignClientUtilPlant feignplant;
  
  @Autowired
	private SequenceGeneratorService service;
  
  @GetMapping("/allplants") 
//	@PreAuthorize("hasRole('USER')  or hasRole('ADMIN')")
	public ResponseEntity<List<Plant>> getAllPlantsInCart() throws PlantNotFoundException
	{
		
		return feignplant.getAllPlants();
		
	}
	
	@GetMapping("/plants/{id}")
//	@PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
	public ResponseEntity<Plant> getPlantByIdInCart( @PathVariable  Integer id)
	throws PlantNotFoundException{
		return feignplant.getPlantById(id);
	}
	
//	@PostMapping("/addplants") 
////	@PreAuthorize("hasRole('ADMIN')")
//	public ResponseEntity<Plant> addPlant(@RequestBody Plant plant)  throws NoProperDataException
//	{
//		plant.setPlantId(service.getSequenceNumberForPlant(Plant.SEQUENCE_NAME));
//		
//		return feignplant.addPlant(plant);
//	}
//
//	@PutMapping("/updateplant/{id}")
////	@PreAuthorize( "hasRole('ADMIN')")
//	public ResponseEntity<Plant> updatePlant( @RequestBody Plant plant,@PathVariable Integer id) throws PlantNotFoundException
//	{
//	return feignplant.updatePlant(plant, id);
//	}
//	
//	@DeleteMapping(path="/plants/{id}")
////	@PreAuthorize("hasRole('ADMIN')")
//	public ResponseEntity<String> deletePlant(@Valid @RequestHeader("Authorization") String token,@PathVariable Integer id) throws PlantNotFoundException {
//			return feignplant.deletePlant(token,id);
//}

  }