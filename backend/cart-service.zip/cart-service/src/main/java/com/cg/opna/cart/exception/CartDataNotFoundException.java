package com.cg.opna.cart.exception;

@SuppressWarnings("serial")
public class CartDataNotFoundException extends Exception{
	
	public CartDataNotFoundException(String ss)
	{
		super(ss);
	}

}
