package com.cg.opna.cart.exception;

@SuppressWarnings("serial")
public class CartNotFoundException extends Exception{
	 
	public CartNotFoundException(String t)
	{
		super(t);
	}
}
