package com.cg.opna.cart.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception{

	public NoProperDataException(String s)
	{
		super(s);
	}
}