package com.cg.opna.cart.exception;

@SuppressWarnings("serial")
public class PlantNotFoundException extends Exception{
	
	public PlantNotFoundException(String s)
	{
		super(s);
	}
}
