package com.cg.opna.cart.model;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Document(collection ="cart")
public class Cart {

	
	@Transient
	public static final String SEQUENCE_NAME = "cart_sequence";
	//which means the field marked with @Transient is ignored by mapping framework and the field not mapped to any database column

	@Id
	private long cartId;
	 private Long plantId;
	private int quantity;
	private String productName;
     private float amount;
	
	
	
	
	
	

}
