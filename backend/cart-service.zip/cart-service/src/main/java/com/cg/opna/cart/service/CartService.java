package com.cg.opna.cart.service;

import java.util.List;

import com.cg.opna.cart.exception.CartNotFoundException;
import com.cg.opna.cart.exception.PlantNotFoundException;
import com.cg.opna.cart.exception.RecordAlreadyExistsException;
import com.cg.opna.cart.model.Cart;



public interface CartService {

	public List<Cart> showAllDataInCarts() throws  CartNotFoundException;
	
	public Cart addCart(Cart cart)  throws RecordAlreadyExistsException;
	public Cart updateCart(Cart cart)  throws CartNotFoundException;
	public String cancelCart(Long id) throws CartNotFoundException;
 

	Cart addCartById(Long plantId, Cart cart) throws PlantNotFoundException;

}