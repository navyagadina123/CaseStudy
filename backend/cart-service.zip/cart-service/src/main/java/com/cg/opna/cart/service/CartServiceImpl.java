package com.cg.opna.cart.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opna.cart.exception.CartNotFoundException;
import com.cg.opna.cart.exception.NoProperDataException;
import com.cg.opna.cart.exception.PlantNotFoundException;
import com.cg.opna.cart.exception.RecordAlreadyExistsException;
import com.cg.opna.cart.model.Cart;
import com.cg.opna.cart.model.Plant;
import com.cg.opna.cart.repository.CartRepository;

import lombok.extern.slf4j.Slf4j;



@Service
@Slf4j
public class CartServiceImpl implements CartService{

	@Autowired
	private CartRepository cartrepo;

	

	/**
	 * @param token'
	 * @return List<Cart>
	 * @throws CartNotFoundException
	 * @throws RecordAlreadyExistsException
	 * @throws InValidTokenException
	 */
	@Override //user/admin
	public List<Cart> showAllDataInCarts() throws CartNotFoundException {


			List<Cart> cartproducts =new ArrayList<>();
			cartproducts =cartrepo.findAll();
			log.debug("cart products from here {}",cartproducts);
			try {
			if(cartproducts.size()==0){
				throw new CartNotFoundException("Cart is empty");
			}
			}catch(CartNotFoundException e)
			{
				log.error(e.getMessage());
			}
		return cartproducts;

	}

	@Override   //only user
	public Cart addCart(Cart cart) throws RecordAlreadyExistsException {
		Cart bean=cartrepo.save(cart);
		log.debug("the cart items are {}",bean);
		try {
			if(bean.getClass().equals(cart.getPlantId())||bean.getClass().equals(cart))
			{
				throw new NoProperDataException("please fill all fields");
			}
		}catch(NoProperDataException nop)
		{
			log.error(nop.getMessage());
		}
		return bean;
	}


	@Override    //only user
	public String cancelCart(Long id) throws CartNotFoundException {
		Optional<Cart> cartDeleted=cartrepo.findById(id);
		log.debug("deleted succesfully {}",cartDeleted);
		if(cartDeleted.isPresent())
		{
			cartrepo.deleteById(id);
			log.debug("deleted succesfully {}",cartDeleted.get());
		}
		else
		{
			throw new CartNotFoundException("id not available to delete");
		}
		return "Deleted";
	}

	@Override
	public Cart updateCart(Cart cart) throws CartNotFoundException {
		return null;
	}

	@Override
	public Cart addCartById(Long plantId,Cart cart) throws PlantNotFoundException {
	
		Cart updatecart = cartrepo.findById(plantId)
              .orElseThrow(() -> new PlantNotFoundException("cart not exist with id: " + plantId));

	  updatecart.setPlantId(cart.getPlantId());
	 

       return cartrepo.save(updatecart);
	

}
	


}
