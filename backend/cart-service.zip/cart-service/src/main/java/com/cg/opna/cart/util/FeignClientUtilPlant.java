package com.cg.opna.cart.util;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cg.opna.cart.model.Plant;


@FeignClient(value = "PlantNursery-Service",url="http://localhost:8086/plant") 
public interface FeignClientUtilPlant {

	
	@GetMapping("/allplants") 
	public ResponseEntity<List<Plant>> getAllPlants();
	
	
	@GetMapping("/plants/{id}")
	public ResponseEntity<Plant> getPlantById(@PathVariable   Integer id);
	
	
//	@PostMapping("/addplants") 
//	public ResponseEntity<Plant> addPlant(Plant plant); 
//
//	@PutMapping("/updateplant/{id}")
//	public ResponseEntity<Plant> updatePlant(@RequestBody Plant plant,@PathVariable Integer id);
//	
//	@DeleteMapping(path="/plants/{id}")
//	
//	public ResponseEntity<String> deletePlant(@RequestHeader("Authorization") String token,Integer id);


		
	}
		
		
		
		
		
	
