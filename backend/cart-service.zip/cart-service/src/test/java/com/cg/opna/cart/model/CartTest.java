//package com.cg.opna.cart.model;
//
//import static org.junit.jupiter.api.Assertions.*;
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//
//
//
//@SpringBootTest
//class CartTest {
//
//	Cart cart;
//	List<Plant> plant;
//	
//	
//	@Test
//	public void cartTest() {
//		Cart cart1 = new Cart();
//		cart1.setId(50);
//		cart1.setId(1);
//		cart1.setPlant(plant);
//		cart1.setPlantcount(1);
//		cart1.getId();
//		cart1.getPlant();
//		cart1.getTotal();
//		
//		
//	}
//	@Test
//	 void getCartIdTest()
//	{
//		assertEquals(50,cart.getId());
//	}	
//	
//	@Test
//	public void defaultConsTest()
//	{
//		Cart cart1=new Cart();
//		Cart cart2=new Cart();
//		assertNotSame(cart1, cart2);
//	}
//}
